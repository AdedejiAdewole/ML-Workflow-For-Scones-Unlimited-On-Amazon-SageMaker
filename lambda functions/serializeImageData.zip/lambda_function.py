import json
import sagemaker
import base64
from sagemaker.serializers import IdentitySerializer
from sagemaker.predictor import Predictor
import boto3
from sagemaker.predictor import Predictor

runtime_client = boto3.client('sagemaker-runtime')

# Fill this in with the name of your deployed model
ENDPOINT = "image-classification-2023-08-09-08-19-49-448" 



def lambda_handler(event, context):
    # Decode the image data

    image = base64.b64decode(event["body"]["image_data"])   

    
    # Instantiate a Predictor
    predictor = runtime_client.invoke_endpoint(
                                        EndpointName=ENDPOINT,
                                        ContentType='image/png',
                                        Body=image              
                                    )

    
    # Make a prediction:
    inferences = json.loads(predictor['Body'].read().decode('utf-8'))
    
    event['inferences'] = inferences 
    # We return the data back to the Step Function    
    return {
        'statusCode': 200,
        'body': event
    }